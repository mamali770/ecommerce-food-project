@extends('layout.master')

@section('title', 'About Page')

@section('content')
    @include('home.about')
@endsection
